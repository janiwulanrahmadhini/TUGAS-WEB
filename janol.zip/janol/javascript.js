/*----Mencetak angka-----
var angka;
angka="10";
document.write(angka*angka);*/

/*------------Penambahan Angka-----
var x;
var y;

x+= 20;
x++;
x-=y;
document.write(x);*/

/*-----------mencetak dokumen menggunakan if else---
var jam=10;

if(jam <= 10)
{
    document.write("pagi");
}
else if(jam > 10 && jam <= 15)
{
    document.write("waktunya mburjo");
    
}
else
{
    document.write("Gabut");
}
*/

/*var jam1=10;

if(jam1 <= 10)
{
    document.write("pagi");
}
var jam2=15;
if(jam2 > 10 && jam2 <= 15)
{
    document.write("waktunya mburjo");
    
}
var jam3=20;
if(jam3>=16)
{
    document.write("Gabut");
}*/

/*var jam=20;
var pesan="";

pesan=(jam <= 10)? "Selamat Pagi": "Selamat Siang";

document.write(pesan);*/

/*----Mencari Variabel Genap----
var i=0;
for(i=0;i<=100;i++)
{
    if(i%2==0)
    document.write("Nomor : " +i);
    document.write("<br/>");
}*/

/*var i=0;
for(i=0;i<=10;i++)
{
    if(i = 3)
    {
        continue//digunakan untuk menghilangkan nilai di kondisi
    }
    document.write("Nomor :" i+);
    document.write("<br/>");
}*/

/*--------Peringatan Menggunakan Kondisi-------
var jam=17;
if(jam<=10)
{
    alert("Selamat Pagi..");

}
else if (jam >10 && jam <= 15)
{
    alert("Selamat Siang..");
}
else
{
    alert("Selamat Sore..");
}*/

/*----- Konfirmasi----------
var konfirmasi= confirm("Apakah Anda Ingin Membuka Halaman Ini?");
if(konfirmasi==true)
{
    document.location.href="halaman1.html";
}
else
{
    document.location.href="home.html";
}*/

var bil1,bil2,jml;
alert("Penjumlahan 2 Bilangan ");

bil1= +prompt("input Bilangan 1 ");
bil2= +prompt("input Bilangan 2");
jml= bil1+bil2;

var konfirmasi=confirm("Apakah Anda Ingin Langsung Melanjutkan?");
if(konfirmasi==true)
{
    document.write("Hasilnya="+jml);
}
else
{
    document.location.href="hello.html";
}
